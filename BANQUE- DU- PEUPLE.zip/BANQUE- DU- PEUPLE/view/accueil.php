<header class="py-5 bg-image-full" style="background-image: url('https://unsplash.it/1900/1080?image=1076');">
    
</header>



<!-- Image Section - set the background image for the header in the line below -->
<section class="py-5 bg-image-full" style="background-image: url('https://unsplash.it/1900/1080?image=1081');">
    <!-- Put anything you want here! There is just a spacer below for demo purposes! -->
    <div style="height: 200px;"></div>
</section>



<section class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white para" >Copyright &copy;2019</p>
    </div>
    <!-- /.container -->

</section>
