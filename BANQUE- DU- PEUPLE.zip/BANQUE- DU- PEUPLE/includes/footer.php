<footer>
    <script src="JS"></script>
    <script src="JS1"></script>
</footer>