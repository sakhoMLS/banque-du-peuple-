<!DOCTYPE html>
<html>
<head>
    <title>BANQUE DU PEUPLE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css">
    <link rel="stylesheet" type="text/css" href="css1">
    <link rel="stylesheet" type="text/css" href="css2">
    <link href="css3" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css4" rel="stylesheet">
</head>
<body>
